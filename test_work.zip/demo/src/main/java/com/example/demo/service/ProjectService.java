package com.example.demo.service;

import com.example.demo.model.Project;
import com.example.demo.model.ProjectSelectDemo;

import java.util.List;

public interface ProjectService {
    Project create(Project project);

    int update(Project project);

    List<Project> getProjectLists(ProjectSelectDemo demo);

    int delete(String ids);
}
