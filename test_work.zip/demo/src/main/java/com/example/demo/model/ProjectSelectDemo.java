package com.example.demo.model;

public class ProjectSelectDemo {
    private String ids;

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }
}
